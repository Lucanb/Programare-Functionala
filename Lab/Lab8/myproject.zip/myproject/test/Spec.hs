module Main where

import Conversion
import Nat
import TestModule

main :: IO ()
main = do
    startTest
